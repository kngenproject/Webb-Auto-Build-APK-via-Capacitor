const fs = require('fs');
const path = require('path');

const SRC = 'src';
const DEST = 'dist';

if (!fs.existsSync(DEST)) fs.mkdirSync(DEST);

function copyDir(src, dest) {
  fs.readdirSync(src).forEach(file => {
    const srcPath = path.join(src, file);
    const destPath = path.join(dest, file);
    if (fs.statSync(srcPath).isDirectory()) {
      if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true });
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  });
}

copyDir(SRC, DEST);
console.log('✅ Build selesai! File disalin ke folder dist/');
