# VoteKu — Capacitor Android Project

## Cara Build APK Android

### Prasyarat
- Node.js v16+ (https://nodejs.org)
- Android Studio (https://developer.android.com/studio)
- Java JDK 17+

### Langkah-langkah

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Tambah platform Android**
   ```bash
   npx cap add android
   ```

3. **Sync file web ke Android**
   ```bash
   npx cap sync android
   ```

4. **Buka di Android Studio**
   ```bash
   npx cap open android
   ```

5. **Build APK di Android Studio**
   - Menu: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - APK akan ada di: `android/app/build/outputs/apk/debug/app-debug.apk`

### Struktur Project
```
project/
├── dist/               ← File website kamu (index.html, dll)
│   ├── icon/
│   │   ├── icon-192.png
│   │   └── icon-512.png
│   ├── index.html
│   ├── manifest.json
│   └── sw.js
├── package.json        ← Dependencies Capacitor
├── capacitor.config.json ← Konfigurasi app
└── README.md           ← Panduan ini
```

### Info App
- **App Name:** VoteKu
- **App ID:** com.voteku.app
- **Web Dir:** dist
